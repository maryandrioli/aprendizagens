//variáveis da bolinha

let xBolinha = 300;
let yBolinha = 200;
let diametro = 80;
let raio = diametro / 2;

// velocidade Bolinha
let velocidadeXBolinha = 5;
let velocidadeYBolinha = 5;

// sons do jogo
let notado;
let re;
let mi;
let fa;
let sol;
let si;

// funcao preload sera para pre carregar os sons do jogo 

function preload () {
  notado = loadSound ("do.mp3");
   re = loadSound ("re.mp3");
   mi = loadSound ("mi.mp3");
  fa = loadSound ("fa.mp3");
    sol = loadSound ("sol.mp3");
     si = loadSound ("si.mp3");
    
}



// funcao setup prepara todo o jogo. Inserir nela o som da trilha usar funcao trilha.play para tocar uma vez ou loop para tocar sempre

function setup() {
    createCanvas(600, 400);
  
}

function draw() {
    background(255, 140, 255);
    mostraBolinha1();
   mostraBolinha2();
  mostraBolinha3();
  mostraBolinha4();
  mostraBolinha5();
  movimentamostraBolinha1 ();
  


    if (keyIsDown(UP_ARROW)){
        fa.play();
      
    }

    if (keyIsDown(DOWN_ARROW)) {
        re.play();
    }

    if (keyIsDown(LEFT_ARROW)) {
        mi.play();
    }
    if (keyIsDown(RIGHT_ARROW)){
          fa.play();
    }

} 
function mostraBolinha1 () { 
     let xBolinha = 100;
    let yBolinha = 300;
    let diametro = 80;
    let raio = diametro / 2;
    circle(xBolinha, yBolinha, diametro); 
 
       
    }


function mostraBolinha2 () { 
     let xBolinha = 200;
    let yBolinha = 300;
    let diametro = 80;
    let raio = diametro / 2;
    circle(xBolinha, yBolinha, diametro);
} 

function mostraBolinha3 () { 
     let xBolinha = 300;
    let yBolinha = 300;
    let diametro = 80;
    let raio = diametro / 2;
    circle(xBolinha, yBolinha, diametro);
} 
    function mostraBolinha4 () { 
     let xBolinha = 400;
    let yBolinha = 300;
    let diametro = 80;
    let raio = diametro / 2;
    circle(xBolinha, yBolinha, diametro);
} 
function mostraBolinha5 () { 
     let xBolinha = 500;
    let yBolinha = 300;
    let diametro = 80;
    let raio = diametro / 2;
    circle(xBolinha, yBolinha, diametro);
} 
  
